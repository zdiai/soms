nvector.objects.FrameL
======================

.. currentmodule:: nvector.objects

.. autoclass:: FrameL

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FrameL.Pvector
      ~FrameL.__init__
   
   

   
   
   