nvector._core.rad
=================

.. currentmodule:: nvector._core

.. autofunction:: rad