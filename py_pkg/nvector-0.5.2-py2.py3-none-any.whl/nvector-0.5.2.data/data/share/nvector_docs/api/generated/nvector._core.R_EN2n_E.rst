nvector._core.R_EN2n_E
======================

.. currentmodule:: nvector._core

.. autofunction:: R_EN2n_E