nvector._core.R2xyz
===================

.. currentmodule:: nvector._core

.. autofunction:: R2xyz