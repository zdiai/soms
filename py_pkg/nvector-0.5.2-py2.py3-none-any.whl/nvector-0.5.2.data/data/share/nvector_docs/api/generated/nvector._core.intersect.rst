nvector._core.intersect
=======================

.. currentmodule:: nvector._core

.. autofunction:: intersect