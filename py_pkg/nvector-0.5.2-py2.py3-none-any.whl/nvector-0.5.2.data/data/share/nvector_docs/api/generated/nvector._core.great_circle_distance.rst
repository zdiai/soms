nvector._core.great_circle_distance
===================================

.. currentmodule:: nvector._core

.. autofunction:: great_circle_distance