nvector.objects.GeoPath
=======================

.. currentmodule:: nvector.objects

.. autoclass:: GeoPath

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GeoPath.__init__
      ~GeoPath.cross_track_distance
      ~GeoPath.interpolate
      ~GeoPath.intersection
      ~GeoPath.nvector_normals
      ~GeoPath.nvectors
      ~GeoPath.track_distance
   
   

   
   
   