nvector._core.unit
==================

.. currentmodule:: nvector._core

.. autofunction:: unit