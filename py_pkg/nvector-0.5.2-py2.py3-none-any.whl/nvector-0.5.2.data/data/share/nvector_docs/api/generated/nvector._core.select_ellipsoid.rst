nvector._core.select_ellipsoid
==============================

.. currentmodule:: nvector._core

.. autofunction:: select_ellipsoid