nvector._core.p_EB_E2n_EB_E
===========================

.. currentmodule:: nvector._core

.. autofunction:: p_EB_E2n_EB_E