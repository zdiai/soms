nvector._core.n_E2R_EN
======================

.. currentmodule:: nvector._core

.. autofunction:: n_E2R_EN