nvector._core.R_EL2n_E
======================

.. currentmodule:: nvector._core

.. autofunction:: R_EL2n_E