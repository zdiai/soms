nvector.objects.FrameB
======================

.. currentmodule:: nvector.objects

.. autoclass:: FrameB

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FrameB.Pvector
      ~FrameB.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~FrameB.R_EN
   
   