nvector.objects.FrameN
======================

.. currentmodule:: nvector.objects

.. autoclass:: FrameN

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FrameN.Pvector
      ~FrameN.__init__
   
   

   
   
   