nvector._core.zyx2R
===================

.. currentmodule:: nvector._core

.. autofunction:: zyx2R