nvector.objects.ECEFvector
==========================

.. currentmodule:: nvector.objects

.. autoclass:: ECEFvector

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ECEFvector.__init__
      ~ECEFvector.change_frame
      ~ECEFvector.to_geo_point
      ~ECEFvector.to_nvector
   
   

   
   
   