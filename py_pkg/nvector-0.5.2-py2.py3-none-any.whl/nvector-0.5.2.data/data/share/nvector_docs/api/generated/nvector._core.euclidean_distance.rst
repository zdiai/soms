nvector._core.euclidean_distance
================================

.. currentmodule:: nvector._core

.. autofunction:: euclidean_distance