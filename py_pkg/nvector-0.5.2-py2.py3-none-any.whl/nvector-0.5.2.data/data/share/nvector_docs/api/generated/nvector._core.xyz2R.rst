nvector._core.xyz2R
===================

.. currentmodule:: nvector._core

.. autofunction:: xyz2R