nvector.objects.FrameE
======================

.. currentmodule:: nvector.objects

.. autoclass:: FrameE

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FrameE.ECEFvector
      ~FrameE.GeoPoint
      ~FrameE.Nvector
      ~FrameE.__init__
      ~FrameE.direct
      ~FrameE.inverse
   
   

   
   
   