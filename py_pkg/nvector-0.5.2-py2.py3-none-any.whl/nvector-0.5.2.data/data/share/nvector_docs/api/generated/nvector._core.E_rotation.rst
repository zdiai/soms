nvector._core.E_rotation
========================

.. currentmodule:: nvector._core

.. autofunction:: E_rotation