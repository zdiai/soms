nvector.objects.diff_positions
==============================

.. currentmodule:: nvector.objects

.. autofunction:: diff_positions