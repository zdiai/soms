nvector._core.cross_track_distance
==================================

.. currentmodule:: nvector._core

.. autofunction:: cross_track_distance