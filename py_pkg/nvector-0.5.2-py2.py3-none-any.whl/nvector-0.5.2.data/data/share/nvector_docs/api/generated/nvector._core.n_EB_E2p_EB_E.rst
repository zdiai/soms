nvector._core.n_EB_E2p_EB_E
===========================

.. currentmodule:: nvector._core

.. autofunction:: n_EB_E2p_EB_E