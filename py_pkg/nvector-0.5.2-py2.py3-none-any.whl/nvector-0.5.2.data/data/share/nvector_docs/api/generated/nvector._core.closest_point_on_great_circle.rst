nvector._core.closest_point_on_great_circle
===========================================

.. currentmodule:: nvector._core

.. autofunction:: closest_point_on_great_circle