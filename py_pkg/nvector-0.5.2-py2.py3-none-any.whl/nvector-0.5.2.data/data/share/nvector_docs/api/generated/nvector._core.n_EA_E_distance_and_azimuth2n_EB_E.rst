nvector._core.n_EA_E_distance_and_azimuth2n_EB_E
================================================

.. currentmodule:: nvector._core

.. autofunction:: n_EA_E_distance_and_azimuth2n_EB_E