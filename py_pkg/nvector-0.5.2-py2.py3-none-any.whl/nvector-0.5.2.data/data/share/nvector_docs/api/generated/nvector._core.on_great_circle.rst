nvector._core.on_great_circle
=============================

.. currentmodule:: nvector._core

.. autofunction:: on_great_circle