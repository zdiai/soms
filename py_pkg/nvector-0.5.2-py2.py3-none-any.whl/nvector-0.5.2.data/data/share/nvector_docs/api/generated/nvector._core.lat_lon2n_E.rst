nvector._core.lat_lon2n_E
=========================

.. currentmodule:: nvector._core

.. autofunction:: lat_lon2n_E