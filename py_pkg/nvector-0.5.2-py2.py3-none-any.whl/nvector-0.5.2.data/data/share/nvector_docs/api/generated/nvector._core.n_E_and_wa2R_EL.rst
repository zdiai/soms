nvector._core.n_E_and_wa2R_EL
=============================

.. currentmodule:: nvector._core

.. autofunction:: n_E_and_wa2R_EL