nvector.objects.Nvector
=======================

.. currentmodule:: nvector.objects

.. autoclass:: Nvector

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Nvector.__init__
      ~Nvector.mean_horizontal_position
      ~Nvector.to_ecef_vector
      ~Nvector.to_geo_point
      ~Nvector.to_nvector
   
   

   
   
   