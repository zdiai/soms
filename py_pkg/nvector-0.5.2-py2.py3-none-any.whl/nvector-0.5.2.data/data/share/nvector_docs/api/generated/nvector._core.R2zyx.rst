nvector._core.R2zyx
===================

.. currentmodule:: nvector._core

.. autofunction:: R2zyx