nvector._core.deg
=================

.. currentmodule:: nvector._core

.. autofunction:: deg