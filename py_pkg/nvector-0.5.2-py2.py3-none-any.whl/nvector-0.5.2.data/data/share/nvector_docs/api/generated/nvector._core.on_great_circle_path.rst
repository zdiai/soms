nvector._core.on_great_circle_path
==================================

.. currentmodule:: nvector._core

.. autofunction:: on_great_circle_path