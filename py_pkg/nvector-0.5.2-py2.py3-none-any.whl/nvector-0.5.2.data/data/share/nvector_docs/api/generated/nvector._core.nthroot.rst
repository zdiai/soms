nvector._core.nthroot
=====================

.. currentmodule:: nvector._core

.. autofunction:: nthroot