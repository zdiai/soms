.. _reference:

Modules
=======

:Release: |version|
:Date: |today|

.. module:: nvector


This reference manual details functions, modules, and objects
included in nvector, describing what they are and what they do.


.. toctree::
   :maxdepth: 4

   nvector
