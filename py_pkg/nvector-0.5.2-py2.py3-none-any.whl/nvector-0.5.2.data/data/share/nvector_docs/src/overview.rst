.. automodule:: nvector._info
   :members: __doc__