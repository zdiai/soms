.. automodule:: nvector._info_functional
   :members: __doc__