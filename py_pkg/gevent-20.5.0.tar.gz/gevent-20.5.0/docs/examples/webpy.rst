=============================
Example webpy.py
=============================
.. literalinclude:: ../../examples/webpy.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/webpy.py>`_

