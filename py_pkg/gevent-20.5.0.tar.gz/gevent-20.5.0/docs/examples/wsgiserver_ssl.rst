=============================
Example wsgiserver_ssl.py
=============================
.. literalinclude:: ../../examples/wsgiserver_ssl.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/wsgiserver_ssl.py>`_

