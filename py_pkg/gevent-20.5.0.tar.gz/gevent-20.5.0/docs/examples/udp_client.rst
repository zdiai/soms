=============================
Example udp_client.py
=============================
.. literalinclude:: ../../examples/udp_client.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/udp_client.py>`_

