=============================
Example dns_mass_resolve.py
=============================
.. literalinclude:: ../../examples/dns_mass_resolve.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/dns_mass_resolve.py>`_

