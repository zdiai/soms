==================================================
 :mod:`gevent._socket3` -- Python 3 socket module
==================================================

.. automodule:: gevent._socket3
    :members:
