""" Illustrates a rudimentary way to implement the "nested sets"
pattern for hierarchical data using the SQLAlchemy ORM.

.. autosource::

"""
