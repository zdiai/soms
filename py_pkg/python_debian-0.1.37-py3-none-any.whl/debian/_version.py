""" Version of the package """

__version__ = '0.1.37'
