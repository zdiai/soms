This implements
`algorithms for geodesics <https://doi.org/10.1007/s00190-012-0578-z>`_
(Karney, 2013) for solving the direct and inverse problems for an
ellipsoid of revolution.

Documentation is available at
`<https://geographiclib.sourceforge.io/1.49/python/>`_.
