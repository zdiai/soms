Changelog
=========

Versions with an odd minor version are unstable releases (e.g. 3.27.x) while
versions with even minor version are stable releases (e.g. 3.28.x). This list
is sorted by release date.

For more details see the GIT log:
https://gitlab.gnome.org/GNOME/pygobject/commits/master

.. include:: ../NEWS
