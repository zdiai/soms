__version__ = '1.1.5'
__VERSION__ = __version__
from .workbook import Workbook
